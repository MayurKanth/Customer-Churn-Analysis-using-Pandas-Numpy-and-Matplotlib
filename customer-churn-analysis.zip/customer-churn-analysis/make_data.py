import numpy as np, pandas as pd
rng = np.random.default_rng(42)
n = 7043
ids = [f"{rng.integers(1000,9999)}-{''.join(rng.choice(list('ABCDEFGHIJKLMNOPQRSTUVWXYZ'),5))}" for _ in range(n)]
df = pd.DataFrame({"customerID": ids})
df["gender"] = rng.choice(["Male","Female"], n)
df["SeniorCitizen"] = rng.choice([0,1], n, p=[.84,.16])
df["Partner"] = rng.choice(["Yes","No"], n, p=[.48,.52])
df["Dependents"] = rng.choice(["Yes","No"], n, p=[.30,.70])
df["Contract"] = rng.choice(["Month-to-month","One year","Two year"], n, p=[.55,.21,.24])
tenure = np.where(df.Contract=="Month-to-month", rng.gamma(1.6,14,n),
         np.where(df.Contract=="One year", rng.normal(38,18,n), rng.normal(52,18,n)))
df["tenure"] = np.clip(tenure.round(),0,72).astype(int)
df["PhoneService"] = rng.choice(["Yes","No"], n, p=[.90,.10])
df["InternetService"] = rng.choice(["DSL","Fiber optic","No"], n, p=[.34,.44,.22])
for c in ["OnlineSecurity","OnlineBackup","DeviceProtection","TechSupport","StreamingTV","StreamingMovies"]:
    v = rng.choice(["Yes","No"], n, p=[.4,.6]).astype(object)
    v[df.InternetService=="No"] = "No internet service"
    df[c] = v
df["PaperlessBilling"] = rng.choice(["Yes","No"], n, p=[.59,.41])
df["PaymentMethod"] = rng.choice(["Electronic check","Mailed check","Bank transfer (automatic)","Credit card (automatic)"], n, p=[.34,.23,.22,.21])
base = np.where(df.InternetService=="DSL",45,np.where(df.InternetService=="Fiber optic",80,20))
mc = base + (df.PhoneService=="Yes")*20 + (df.StreamingTV=="Yes")*8 + (df.StreamingMovies=="Yes")*8 \
     + (df.OnlineSecurity=="Yes")*5 + (df.TechSupport=="Yes")*5 + rng.normal(0,3,n)
df["MonthlyCharges"] = np.clip(mc,18.25,118.75).round(2)
# churn probability driven by realistic factors
z = -1.55 + 1.5*(df.Contract=="Month-to-month") - 1.2*(df.Contract=="Two year") \
    - 0.035*df.tenure + 0.7*(df.InternetService=="Fiber optic") \
    + 0.6*(df.PaymentMethod=="Electronic check") + 0.015*(df.MonthlyCharges-65) \
    + 0.25*df.SeniorCitizen - 0.4*(df.TechSupport=="Yes") - 0.3*(df.OnlineSecurity=="Yes")
p = 1/(1+np.exp(-z))
df["Churn"] = np.where(rng.random(n)<p,"Yes","No")
tc = (df.tenure*df.MonthlyCharges*rng.uniform(.97,1.03,n)).round(2).astype(object)
tc[df.tenure==0] = " "          # blank strings, like the real Telco data
df["TotalCharges"] = tc
# a few messy touches for the cleaning section
df = pd.concat([df, df.sample(15, random_state=1)], ignore_index=True)  # 15 duplicate rows
df.to_csv("data/telco_churn.csv", index=False)
print(df.shape, (df.Churn=="Yes").mean())
