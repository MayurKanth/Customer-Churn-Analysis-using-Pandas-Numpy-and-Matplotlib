# Customer Churn & Revenue Analysis

## Business Problem
A subscription company is losing customers every month. This project finds who is churning, why, and how much revenue is at risk, then recommends actions.

## Key Findings
- Overall churn rate: 27.6% (about $174K of monthly revenue lost)
- Month-to-month customers churn far more than two-year customers
- 40% of churners leave within their first 12 months
- Electronic-check payers churn at 33.1% vs 24.7% for other methods
- High-risk customers (rule-based score) churn at 63.6% vs 7.8% for low-risk

## Dashboard
![Dashboard](images/dashboard.png)

## Approach
1. Cleaned data with pandas (duplicates, `TotalCharges` type fix, missing values)
2. Calculated churn rate, revenue lost and customer lifetime value
3. Segmented customers by contract, tenure, payment method and service
4. Built a rule-based risk score with NumPy (`np.where`, `np.select`)
5. Estimated revenue saved from a retention campaign
6. Visualised results with matplotlib

## Project Structure
```
data/telco_churn.csv          dataset (synthetic, Telco-style)
notebooks/churn_analysis.ipynb  full analysis
images/dashboard.png          final dashboard
make_data.py                  script that generated the dataset
```

## How to Run
```bash
pip install -r requirements.txt
jupyter notebook notebooks/churn_analysis.ipynb
```

## Data Source
Synthetic data generated with NumPy (`make_data.py`) to mirror the structure of the
[Kaggle Telco Customer Churn dataset](https://www.kaggle.com/datasets/blastchar/telco-customer-churn).
You can drop the real CSV into `data/` with the same filename and rerun the notebook.
